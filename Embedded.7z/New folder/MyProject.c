// LCD module connections
void Rotation0() //0 Degree
{
unsigned int i;
for(i=0;i<50;i++)
{
PORTC.F0 = 1;
Delay_us(800); // pulse of 800us
PORTC.F0 = 0;
Delay_us(19200);
}
}

void Rotation90() //90 Degree
{
unsigned int i;
for(i=0;i<50;i++)
{
PORTC.F0 = 1;
Delay_us(1500); // pulse of 1500us
PORTC.F0 = 0;
Delay_us(18500);
}
}

void Rotation180() //180 Degree
{
unsigned int i;
for(i=0;i<50;i++)
{
PORTC.F0 = 1;
Delay_us(2200); // pulse of 2200us
PORTC.F0 = 0;
Delay_us(17800);
}
}
sbit LCD_RS at RD2_bit;
sbit LCD_EN at RD3_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D7 at RD7_bit;
sbit LCD_RS_Direction at TRISD2_bit;
sbit LCD_EN_Direction at TRISD3_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections

//defining port of keypad
char keypadport at portB;

//fucntion to get password
char get_password ()
{

char password[4];
int i;

loop:
Lcd_Cmd(_LCD_CLEAR);               // Clear display
Lcd_Out(1,2,"Enter Password");
password[0]=0;
password[1]=0;
password[2]=0;
password[3]=0;
for (i=0; i<3; i++){
while (password[i]==0)
{
password[i]=keypad_key_click();
}
if (password[i]==1){password[i]='1';}
else if (password[i]==2){password[i]='2';}
else if (password[i]==3){password[i]='3';}
else if (password[i]==4){password[i]='4';}
else if (password[i]==5){password[i]='5';}
else if (password[i]==6){password[i]='6';}
else if (password[i]==7){password[i]='7';}
else if (password[i]==8){password[i]='8';}
else if (password[i]==9){password[i]='9';}
else if (password[i]==0){password[i]='0';}
Lcd_Out(2,i+1,"*");
delay_ms(100);
}
if (strcmp(password,"123")==0){
return 1; }
else
return 0;
}
void main()
{
  TRISC=0x00;
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  Lcd_Cmd(_LCD_CLEAR);
  keypad_init();
  Lcd_Out(1,3,"Enter Password");
  delay_ms(100);
  Lcd_Cmd(_LCD_CLEAR);
//calling function
if (get_password()==1)
{
Lcd_Cmd(_LCD_CLEAR);
Lcd_Out(1,3,"Access Granted");
delay_ms(1500);
Rotation180();
}
if (get_password()==0)
{
Lcd_Cmd(_LCD_CLEAR);
Lcd_Out(1,3,"Access Denied");
delay_ms(1500);
TRISC=0x00;
PORTC=PORTC|0x01;
TRISA = 0x00;
PORTA = 0xFF;
Rotation0();
delay_ms(1500);
PORTA= 0x00;

}  }