sbit LCD_RS at RD0_bit;
sbit LCD_EN at RD1_bit;
sbit LCD_D4 at RD2_bit;
sbit LCD_D5 at RD3_bit;
sbit LCD_D6 at RD4_bit;
sbit LCD_D7 at RD5_bit;

sbit LCD_RS_Direction at TRISD0_bit;
sbit LCD_EN_Direction at TRISD1_bit;
sbit LCD_D4_Direction at TRISD2_bit;
sbit LCD_D5_Direction at TRISD3_bit;
sbit LCD_D6_Direction at TRISD4_bit;
sbit LCD_D7_Direction at TRISD5_bit;
// End LCD module connections
void ATD_init(void);
void CCPPWM_init(void);
void motor(unsigned char);
unsigned int ATD_read(void);
unsigned char myspeed;
char display[16]="";
void interrupt(void);
void Delay(int x);

unsigned int Mcntr;
unsigned char cntr;
unsigned int period, duty;
unsigned char Direction;
unsigned int result;
unsigned char dcntr;
unsigned int k;
unsigned char myscaledVoltage;

unsigned char flag=10;
unsigned char flagtemp=10;
float voltage, temperature;

void main() {
     ATD_init(); // initialize the ATD module
     cntr=0;
     Mcntr=0;
     TMR0=248;
     OPTION_REG = 0x87;//Fosc/4 with 256 prescaler => incremetn every 0.5us*256=128us ==> overflow 8count*128us=1ms to overflow
     INTCON = 0xA0; // GIE, T0IE and INTE (TMR) overflow interrupt and External Interrupt Enable)
     CCPPWM_init();
     TRISC = 0xF0;
     TRISB = 0x01;
     TRISA = 0xff;
     PORTB = 0x00;
     PORTC = 0xF0;

     lcd_init();
     lcd_cmd(_lcd_clear);
     lcd_cmd(_LCD_CURSOR_OFF);
     lcd_out(1,1,"smart store");
     Delay(800);
     lcd_cmd(_lcd_clear);


while(1)
{
        result=ATD_read();          // Reading ADC values
        voltage=result*4.88;        // Convert it into the voltage
        temperature =voltage/10;    // Getting the temperature values
        lcd_out(1,1,"Temp = ");
        floattostr(temperature,display);
        lcd_out_cp(display);
        lcd_chr(1,14,223);          //print at pos(row=1,col=13) "�" =223 =0xdf
        lcd_out_cp("C");            //celcius
        Delay(500);
        if(temperature > 26 && temperature < 27){
        myspeed=0;
        motor(myspeed);
        Delay(200);}       // 0% speed
        if(temperature>27&&temperature<28){
        motor(myspeed>>2);
        Delay(200);}   // 25% speed
        if(temperature>28&&temperature<29){
        motor(myspeed>>1);
        Delay(200);}    // 50% speed
        if(temperature>29&&temperature<30){
        motor(3*(myspeed>>2));
        Delay(200);        } // 75% speed
        if(temperature>30){
        motor(myspeed);
        Delay(200);}        //100% speed

        else {
        lcd_cmd(_lcd_clear);
        }
        if(PORTC&0x10&&PORTC&0x20){
        lcd_out(2,2,"DISCOUNT! 10$");
        }

  else if (PORTC&0x10){
                  lcd_out(2,2,"price is 5$ "); }
  else  if (PORTC&0x20){
                  lcd_out(2,2,"price is 7$ "); }





}
}


void Delay(int x){
     Mcntr=0;
     while(Mcntr<x);
}


void interrupt(void){
if(INTCON&0x04){  // will get here every 1ms
    TMR0=248;
    Mcntr++;
    dcntr++;
if(dcntr==10){
             dcntr=0;
             if(PORTB & 0x01){
             flag=0;
             }
             else{
             flag=1;
             }

}

}
INTCON = INTCON & 0xFB; //clear T0IF
}

void ATD_init(void){
ADCON0=0x41;//ON, Channel 0, Fosc/16== 500KHz, Dont Go
ADCON1=0xCE;// RA0 Analog, others are Digital, Right Allignment,
TRISA=0x01;
}


unsigned int ATD_read(void){
         ADCON0=ADCON0 | 0x04;//GO
         while(ADCON0&0x04);//wait until DONE
         return (ADRESH<<8)|ADRESL;
}

void CCPPWM_init(void){ //Configure CCP1 and CCP2 at 2ms period with 50% duty cycle
  T2CON = 0x27;//enable Timer2 at Fosc/4 with 1:16 prescaler (8 uS percount 2000uS to count 250 counts)
  CCP1CON = 0x0C;//enable PWM for CCP1
  CCP2CON = 0x0C;//enable PWM for CCP2
  PR2 = 250;// 250 counts =8uS *250 =2ms period
  TRISC = 0x00;
  CCPR1L= 125;
}
void motor(unsigned char speed){ //fan motor
     //speed 0-250
     CCPR1L=speed;
}